<?php
require("db.php");
date_default_timezone_set("Asia/Tehran");
mysqli_set_charset($db, 'utf8');
?>

<!DOCTYPE html>
<html lang="fa">
<head>
<div class="input-container">
  <input type="text" placeholder="Add Item">
  <button class="button">سرچ</button>
</div>



<style>

.input-container {
  display: flex;
  background: white;
  border-radius: 1rem;
  background: linear-gradient(135deg, #23272F 0%, #14161a 100%);
  box-shadow: 10px 10px 20px #0e1013, -10px -10px 40px #383e4b;
  padding: 0.3rem;
  gap: 0.3rem;
}

.input-container input {
  border-radius: 0.8rem 0 0 0.8rem;
  background: #23272F;
  box-shadow: inset 5px 5px 10px #0e1013, inset -5px -5px 10px #383e4b, 0px 0px 100px rgba(255, 212, 59, 0), 0px 0px 100px rgba(255, 102, 0, 0);
  width: 100%;
  flex-basis: 75%;
  padding: 1rem;
  border: none;
  border: 1px solid transparent;
  color: white;
  transition: all 0.2s ease-in-out;
}

.input-container input:focus {
  border: 1px solid #FFD43B;
  outline: none;
  box-shadow: inset 0px 0px 10px rgba(255, 102, 0, 0.5), inset 0px 0px 10px rgba(255, 212, 59, 0.5), 0px 0px 100px rgba(255, 212, 59, 0.5), 0px 0px 100px rgba(255, 102, 0, 0.5);
}

.input-container button {
  flex-basis: 25%;
  padding: 1rem;
  background: linear-gradient(135deg, rgb(255, 212, 59) 0%, rgb(255, 102, 0) 100%);
  box-shadow: 0px 0px 1px rgba(255, 212, 59, 0.5), 0px 0px 1px rgba(255, 102, 0, 0.5);
  font-weight: 900;
  /* letter-spacing: 0.3rem; */
  text-transform: uppercase;
  color: #23272F;
  border: none;
  width: 100%;
  border-radius: 0 1rem 1rem 0;
  transition: all 0.2s ease-in-out;
  /* font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; */



}

.input-container button:hover {
  background: linear-gradient(135deg, rgb(255, 212, 59) 50%, rgb(255, 102, 0) 100%);
  box-shadow: 0px 0px 100px rgba(255, 212, 59, 0.5), 0px 0px 100px rgba(255, 102, 0, 0.5);
}

@media (max-width: 500px) {
  .input-container {
    flex-direction: column;
  }

  .input-container input {
    border-radius: 0.8rem;
  }

  .input-container button {
    padding: 1rem;
    border-radius: 0.8rem;
  }
}
</style>


    <meta charset="utf-8">
    <title>آگهی‌های ثبت شده</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <style>
        body{
            background-color:black;
            
        }
        .main {
            direction: rtl;
            font-family: 'IRANSans', Tahoma, Arial, sans-serif;
        }
        .agahi1 {
            margin-bottom: 20px;
            padding: 10px;
            background-color: black;
            border-radius: 5px;
            box-shadow: 1px 1px 1rem #57ff95;
        }
        .agahi2 {
            padding: 10px;
        }
        .agahi-image {
            text-align: center;
            margin-bottom: 10px;
        }
        .agahi-image img {
            max-width: 100%;
            border-radius: 5px;
        }
        .agahi-details {
            margin-top: 10px;
        }
        .agahi-details p {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
    </style>
</head>



<body class="main">
<div class="container mt-5">
    <div class="row">
        <?php
        $sql = mysqli_query($db, "SELECT * FROM agahi ORDER BY id DESC");

        while ($row = mysqli_fetch_assoc($sql)) {
            $company_name = $row['company_name'];
            $work_experience = $row['work_experience'];
            $reward = $row['reward'];
            $business_travel = $row['business_travel'];
            $skills = $row['skills'];
            $image = $row['image'];

            echo '
            <div class="col-md-4">
                <div class="agahi1">
                    <div class="agahi-image">
                        <img src="'. $image .'" alt="تصویر آگهی">
                    </div>
                    <div class="agahi-details">
                        <p><strong>نام شرکت:</strong> '. $company_name .'</p>
                        <p><strong>سابقه کاری:</strong> '. $work_experience .'</p>
                        <p><strong>پاداش:</strong> '. $reward .'</p>
                        <p><strong>سفر های کاری:</strong> '. $business_travel .'</p>
                        <p><strong>مهارت:</strong> '. $skills .'</p>
                    </div>
                </div>
            </div>
            ';
        }
        ?>
    </div>
</div>
<?php include("footer.php") ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
