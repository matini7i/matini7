export declare const ioniconContent: Map<string, string>;
export declare const getSvgContent: (url: string, sanitize: boolean) => Promise<any>;
