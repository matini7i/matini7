export { addIcons } from './components/icon/utils';
