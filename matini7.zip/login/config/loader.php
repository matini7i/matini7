<?php
require_once('database.php');