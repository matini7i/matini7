<?php

$db = mysqli_connect('localhost','root','','chat new');
// $db = mysqli_connect('aiolearnfamily.com','aiolear3_project_admin','*****','aiolear3_project');


?>