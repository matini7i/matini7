# alix-css
Alix app css module

To add submodule with different folder name
git submodule add https://github.com/jb-mobile-webapp/alix-css.git css
